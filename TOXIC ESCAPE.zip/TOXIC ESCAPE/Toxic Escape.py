import pygame
import sys
import random
import math
import time

# Inicializar Pygame
pygame.init()
pygame.mixer.init()

# Tamaño y ventana
ANCHO, ALTO = 800, 600
ventana = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Toxic Escape")

# Colores
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
ROJO = (200, 0, 0)
AZUL = (100, 100, 255)
MORADO_OSCURO = (70, 30, 100)

# Fuentes
fuente_peque = pygame.font.SysFont("arial", 24)
fuente_titulo = pygame.font.SysFont("arial", 60, bold=True)
fuente_sala1 = pygame.font.SysFont("arial", 40)

# FPS y reloj
FPS = 60
clock = pygame.time.Clock()

# Cargar fondo menú
try:
    fondo = pygame.image.load("menu_bg.jpg")
    fondo = pygame.transform.scale(fondo, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar el fondo:", e)
    fondo = None

#Cargar imagen de las reglas
try:
    imagen_reglas = pygame.image.load("Reglas.png")
    imagen_reglas = pygame.transform.scale(imagen_reglas, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar la imagen de las reglas:", e)
    imagen_reglas = None
#cargar imagen de victoria
try:
    imagen_victoria = pygame.image.load("victoria_bg.png")
    imagen_victoria = pygame.transform.scale(imagen_victoria, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar la imagen de victoria:", e)
    imagen_victoria = None

#carga la imagen de derrota
try:
    imagen_derrota = pygame.image.load("menu_perdiste.png")
    imagen_derrota = pygame.transform.scale(imagen_derrota, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar la imagen de derrota", e)
    imagen_derrota = None

#cargar la imagen de la sala 1
try:
    fondo_sala1 = pygame.image.load("salas/fondo_sala1.jpg")
    fondo_sala1 = pygame.transform.scale(fondo_sala1, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar el fondo de la sala 1", e)
    fondo_sala1 = None
#Cargar imagen de la sala 2
try:
    fondo_sala2 = pygame.image.load("salas/fondo_sala2.jpg")
    fondo_sala2 = pygame.transform.scale(fondo_sala2, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar la imagen de la sala 2", e)
    fondo_sala2 = None
#cargar imagen de la sala3
try:
    fondo_sala3 = pygame.image.load("salas/fondo_sala3.jpg")
    fondo_sala3 = pygame.transform.scale(fondo_sala3, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar la imagen de la sala 3", e)
    fondo_sala3 = None
#cargar imagen de la sala4
try:
    fondo_sala4 = pygame.image.load("salas/fondo_sala4.jpg")
    fondo_sala4 = pygame.transform.scale(fondo_sala4, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar la imagen sala4", e)
    fondo_sala4 = None
#cargar imageen de la sala 5
try: 
    fondo_sala5 = pygame.image.load("salas/fondo_sala5.jpg")
    fondo_sala5 = pygame.transform.scale(fondo_sala5, (ANCHO, ALTO))
except Exception as e:
    print("No se pudo cargar la imagen de la sala5")
    fondo_sala5 = None
#cargar imagen corazon vidas
try:
    corazonvidas = pygame.image.load("corazon.png").convert_alpha()
    corazonvidas = pygame.transform.scale(corazonvidas, (30,30))
except Exception as e:
    print("No se pudo cargar el fondo de la sala 1", e)
    corazonvidas = None
#cargar imagend de la botella
try:
    imagen_botella = pygame.image.load("botella.png").convert_alpha()
    imagen_botella = pygame.transform.scale(imagen_botella, (40, 60))
except Exception as e:
    print("No se pudo cargar la imagen de la botella", e)
    imagen_botella = None
#cargar imagenes del gas
sprites_gas = []
for i in range(6):
    try:
        imagen_gas = pygame.image.load(f"gas/gas_{i}.png").convert_alpha()
        sprites_gas.append(imagen_gas)
    except Exception as e:
        print(f"No se pudo cargar gas_{i}.png", e)
#cargar imagenes del gas de la sala4
try:
    imagen_gas_oscuro = pygame.image.load("gas_oscuro.png").convert_alpha()
except Exception as e:
    print("No se pudo cargar la iamgen del gas oscuro", e)
    imagen_gas_oscuro = None

try:
    imagen_gas_frente = pygame.image.load("gas_frente.png").convert_alpha()
except Exception as e:
    print("No se pudo cargar la imagen del gas del frente", e)
    imagen_gas_frente = None
#sprites para el jugador
sprites_jugador = {
    "abajo": [],
    "arriba": [],
    "derecha": [],
    "izquierda": []
}
#cargar los sprites
for direccion in sprites_jugador.keys():
    for i in range(1, 5):
        try:
            img = pygame.image.load(f"sprites_jugador/jugador/personaje_{direccion}{i}.png").convert_alpha()
            img = pygame.transform.scale(img, (50, 50))
            sprites_jugador[direccion].append(img)
        except Exception as e:
            print(f"No se pudo cargar personaje_{direccion}_{i}.png", e)
#personaje de pie
sprites_quieto = {}
for direccion in ["arriba", "abajo", "izquierda", "derecha"]:
    try:
        img_quieto = pygame.image.load(f"personaje_de_pie/personaje_pie_{direccion}.png").convert_alpha()
        img_quieto = pygame.transform.scale(img_quieto, (40, 40))
    except Exception as e:
        print(f"No se pudo cargar personaje_pie_{direccion}.png", e)
        sprites_quieto[direccion] = None
#Sprites del guardia
sprites_guardia = {
    "arriba": [],
    "derecha": [],
    "izquierda": []
}
#Cantidad de sprites
cantidad_sprites_guardia = {
    "arriba": 2,
    "derecha": 3,
    "izquierda": 3
}
for direccion in sprites_guardia:
    for i in range(1,cantidad_sprites_guardia[direccion] + 1 ):
        try:
            img_guardia = pygame.image.load(f"sprites_guarda/guarda_{direccion}{i}.png").convert_alpha()
            img_guardia = pygame.transform.scale(img_guardia, (40, 40))
            sprites_guardia[direccion].append(img_guardia)
        except Exception as e:
            print(f"No se pudo cargar guarda_{direccion}{i}.png", e)
#archivos de musica
menu_ = "menu_musica.mp3"
menu_juego = "menu_juego.mp3"
menu_derrota = "menu_derrota.mp3"
menu_victoria = "menu_victoria.mp3"
# Estados del juego
MENU = "menu"
REGLAS = "reglas"
JUEGO = "juego"
PERDISTE = "perdiste"
VICTORIA = "victoria"
estado = MENU

# Botones del menú principal
botones = {
    "JUGAR": pygame.Rect(312, 142, 240, 50),
    "REGLAS": pygame.Rect(312, 205, 240, 50),
    "SALIR": pygame.Rect(312, 265, 240, 50)
}

# Botones de pantalla de derrota
botones_derrota = {
    "VOLVER A JUGAR": pygame.Rect(340, 371, 380, 58),
    "SALIR": pygame.Rect(430, 460, 200, 50),
    "VOLVER AL MENU": pygame.Rect(415, 533, 237, 50)
}

botones_victoria = {
    "JUGAR DE NUEVO": pygame.Rect(166, 475, 470, 52),
    "SALIR": pygame.Rect(166, 540, 470, 52)
}

#Obstaculos de la sala1
# Lista de obstáculos de la sala (mesas, sillas, muebles, plantas, etc.)
obstaculos_sala1 = [
    pygame.Rect(0, 0, 380, 170),        # Pared superior-
    pygame.Rect(0, 0, 100, 600),        # Pared izquierda-
    pygame.Rect(780, 0, 20, 600),      # Pared derecha
    pygame.Rect(0, 500, 900, 800),      # Pared inferior
    pygame.Rect(450, 0, 980, 170),

    # Plantas (zona aproximada)
    pygame.Rect(260, 100, 30, 100),
    pygame.Rect(497, 150, 30, 50),
    pygame.Rect(711, 160, 100, 105),
   
]
#Obstaculos de la sala 2
obstaculos_sala2 = [
    pygame.Rect(0, 0, 1600, 225),     # pared superior
    pygame.Rect(0, 0, 30, 600),      # Pared izquierda
    pygame.Rect(0, 410, 1600, 300)    # Pared inferior
]
#Obstaculos de la sala3
obstaculos_sala3 = [
    #parerdes del pasillo central
    pygame.Rect(0, 380, 75, 200), #listo
    pygame.Rect(700, 380, 100, 200), #listo
    pygame.Rect(350, 0, 100, 95), #listo
    pygame.Rect(0, 10, 30, 600),
    #Muebles y mesas
    pygame.Rect(20, 150, 300, 100), #listo
    pygame.Rect(20, 10, 335, 200), #listo
    pygame.Rect(5, 475, 350, 150),
    #Muebles y mesas del lado derecho
    pygame.Rect(520, 150, 280, 100), #listo
    pygame.Rect(445, 10, 400, 200), #listo
    pygame.Rect(480, 480, 350, 100), #listo
]
#obstaculos de la sala 4
obstaculos_sala4 = [
    pygame.Rect(10, 30, 450, 175),    #LITSO1
    pygame.Rect(450, 30, 350, 140),   # LISTO2
    pygame.Rect(40, 440, 200, 100),   # LISTO4
    pygame.Rect(320, 450, 70, 100),   # LISTO7
    pygame.Rect(420, 430, 180, 100),  # LISTO3
    pygame.Rect(645, 380, 60, 145),   # LISTO6
    pygame.Rect(720, 240, 80, 250),  # LISTO5
]
#obstaculos de la sala 5
obstaculos_sala5 = [
    #Muebles
    pygame.Rect(20, 160, 230, 180),#Listo
    pygame.Rect(550, 160, 230, 180),#Lsito
    pygame.Rect(465, 410, 350, 165),#Listo
    pygame.Rect(1, 410, 350, 165),#Listo
    pygame.Rect(370, 480, 70, 40),#Listo
    #Paredes
    pygame.Rect(0, 0,   ANCHO, 70),
    pygame.Rect(0, 560, ANCHO, 40),
    pygame.Rect(-35, 0, 40, ALTO),
    pygame.Rect(795, 0, 40, ALTO),
]
# Variables del jugador y juego
vidas = 5
jugador = pygame.Rect(100, 300, 40, 40)
direccion_jugador = "abajo"
velocidad = 3
sala_actual = 1
mostrar_mensaje = True
tiempo_mensaje = 0
puerta_cerrada = pygame.Rect(380, 40, 50, 72)
mostrar_mensaje_puerta_cerrada = False
tiempo_mensaje_puerta_cerrada = 0
frame_actual = 0
contador_animacion = 0
frecuencia_animacion = 4
tiempo_total = 100 #segundos
tiempo_inicio = pygame.time.get_ticks()

# Variables sala 2
botellas = []
velocidad_botella = 5
tiempo_spawn_botella = -1
spawn_interval = FPS * 0.5  # cada 2 segundos

#Variables de la sala 3
Conductos = []
gases_activos = []
tiempo_spawn_gas = 0
spawn_interval_gas = FPS * 1.8
duracion_gas = FPS * 2
cooldown_gas = 0

#variables de la sala 4
gas_sala4 = None
gas_velocidad = 1
tiempo_inicio_sala4 = 0
puertas_sala4 = []
puerta_abierta = None
tiempo_puerta = 0
mostrar_mensaje_puerta = False
tiempo_mensaje_puerta = 0
jugador_se_movio_sala4 = False
tiempo_espera_gas_sala4 = 0
capa_mancha = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)

# Variables de la sala 5
guarda = pygame.Rect(0, 0, 30, 60)
camino_correcto = 0
inicio_dialogo_guardia = 0
guardia_hablando = False
Guardia_caminando = False
Guardia_esperando = False
puertas_sala5 = []
mensaje_mostrado = False
guarda_fase_moviedonse = "entrada"
destino_x_guadra = 0
direccion_guardia = "derecha"
frame_guardia = 0
contador_guardia = 0
frecuencia_animacion_guardia = 8


def dibujar_menu():

    if fondo:
        ventana.blit(fondo, (0, 0))
    else:
        ventana.fill((50, 50, 80))

def mostrar_reglas():
    if imagen_reglas:
        ventana.blit(imagen_reglas, (0, 0))
    else:
        ventana.fill((50, 50, 80))

def dibujar_vidas(ventana, vidas):
    ancho_corazon = 30
    espacio = 10
    x_inicio = 10
    y_inicio = 10
    for i in range(vidas):
        x = x_inicio + i * (ancho_corazon + espacio)
        if corazonvidas:
            ventana.blit(corazonvidas, (x,y_inicio))
        else:
            rect = pygame.Rect(x,y_inicio,ancho_corazon,ancho_corazon)
            pygame.draw.rect(ventana,ROJO,rect)

def mover_jugador(teclas, jugador, velocidad, obstaculos):
    global direccion_jugador
    nuevo_jugador = jugador.copy()

    if teclas[pygame.K_LEFT]:
        nuevo_jugador.x -= velocidad
        direccion_jugador = "izquierda"
    if teclas[pygame.K_RIGHT]: 
        nuevo_jugador.x += velocidad
        direccion_jugador = "derecha"
    if teclas[pygame.K_UP]: 
        nuevo_jugador.y -= velocidad
        direccion_jugador = "arriba"
    if teclas[pygame.K_DOWN]:
        nuevo_jugador.y += velocidad
        direccion_jugador = "abajo"

    #verificar colisiones 
    colisiona = any(nuevo_jugador.colliderect(obs) for obs in obstaculos)
    if not colisiona:
        jugador.x, jugador.y = nuevo_jugador.x, nuevo_jugador.y

def dibujar_jugador_animado(x, y, teclas):
    global direccion_jugador, frame_actual, contador_animacion

    movimiento = teclas[pygame.K_LEFT] or teclas[pygame.K_RIGHT] or teclas[pygame.K_UP] or teclas[pygame.K_DOWN]

    if movimiento:
        contador_animacion += 1
        if contador_animacion >= frecuencia_animacion:
            contador_animacion = 0
            frame_actual = (frame_actual + 1) % len(sprites_jugador[direccion_jugador])
        if sprites_jugador[direccion_jugador]:
            ventana.blit(sprites_jugador[direccion_jugador][frame_actual], (x, y))
    else:
        if sprites_quieto[direccion_jugador]:
            ventana.blit(sprites_quieto[direccion_jugador], (x, y))
        else:
            ventana.blit(sprites_jugador[direccion_jugador][0], (x, y))

def cambiar_a_derrota():
    global estado
    estado = PERDISTE


def mostrar_cronometro():
    global tiempo_total, tiempo_inicio, estado

    # Tiempo transcurrido en segundos
    tiempo_pasado = (pygame.time.get_ticks() - tiempo_inicio) // 1000
    tiempo_restante = max(0, tiempo_total - tiempo_pasado)

    # Formato MM:SS
    minutos = tiempo_restante // 60
    segundos = tiempo_restante % 60
    texto_tiempo = f"{minutos:02}:{segundos:02}"

    # Fuente y texto
    fuente = pygame.font.SysFont("Arial", 36)
    imagen_texto = fuente.render(texto_tiempo, True, (255, 255, 255))

    # Posición del texto
    texto_rect = imagen_texto.get_rect(topright=(ANCHO - 20, 10))

    # Crear fondo negro semitransparente
    fondo = pygame.Surface((texto_rect.width + 20, texto_rect.height + 10), pygame.SRCALPHA)
    fondo.fill((0, 0, 0, 180))  # (R, G, B, ALPHA)

    # Dibujar el fondo y luego el texto
    ventana.blit(fondo, (texto_rect.right - fondo.get_width(), texto_rect.top - 5))
    ventana.blit(imagen_texto, texto_rect)

    # Si se acaba el tiempo, cambiar al estado de derrota
    if tiempo_restante == 0 and estado == JUEGO:
        cambiar_a_derrota()
def reproducir_musica(ruta, repetir=True):
    try:
        pygame.mixer.music.stop()
        pygame.mixer.music.load(ruta)
        pygame.mixer.music.play(-1 if repetir else 0)
    except Exception as e:
        print("Error al reproducir música:", e)





def sala_1():
   
    global mostrar_mensaje, tiempo_mensaje, sala_actual, estado
    global mostrar_mensaje_puerta_cerrada, tiempo_mensaje_puerta_cerrada
    global direccion_jugador, frame_actual, contador_animacion

    if fondo_sala1:
        ventana.blit(fondo_sala1, (0, 0))
    else:
        ventana.fill((210, 210, 210))
    mostrar_cronometro()


    # Mostrar mensaje inicial
    if mostrar_mensaje:
        objetivo = fuente_peque.render("Mantén la calma, busca la salida", True, NEGRO)
        ventana.blit(objetivo, (ANCHO // 2 - objetivo.get_width() // 2, 20))
        tiempo_mensaje += 1
        if tiempo_mensaje > FPS * 3:
            mostrar_mensaje = False

    # Movimiento jugador
    teclas = pygame.key.get_pressed()
    mover_jugador(teclas, jugador, velocidad, obstaculos_sala1)

    # Animación del jugador
    if teclas[pygame.K_LEFT] or teclas[pygame.K_RIGHT] or teclas[pygame.K_UP] or teclas[pygame.K_DOWN]:
        contador_animacion += 1
        if contador_animacion >= frecuencia_animacion:
            contador_animacion = 0
            frame_actual = (frame_actual + 1) % len(sprites_jugador[direccion_jugador])
        if sprites_jugador[direccion_jugador]:
            ventana.blit(sprites_jugador[direccion_jugador][frame_actual], (jugador.x, jugador.y))
    else:
        if sprites_quieto[direccion_jugador]:
            ventana.blit(sprites_quieto[direccion_jugador], (jugador.x, jugador.y))
        else:
            ventana.blit(sprites_jugador[direccion_jugador][0], (jugador.x, jugador.y))

    

    # Dibujar vidas
    dibujar_vidas(ventana, vidas)

    # Puerta de salida
    puerta_salida = pygame.Rect(730, 290, 900, 85)
    if jugador.colliderect(puerta_salida):
        sala_actual = 2
        jugador.x, jugador.y = 100, 300
        mostrar_mensaje = True
        tiempo_mensaje = 0

    # Puerta cerrada
    if jugador.colliderect(puerta_cerrada):
        mostrar_mensaje_puerta_cerrada = True
        tiempo_mensaje_puerta_cerrada = FPS * 2
        if direccion_jugador == "izquierda":
            jugador.x += velocidad
        elif direccion_jugador == "derecha":
            jugador.x -= velocidad
        elif direccion_jugador == "arriba":
            jugador.y += velocidad
        elif direccion_jugador == "abajo":
            jugador.y -= velocidad

    if mostrar_mensaje_puerta_cerrada:
        texto = fuente_sala1.render("La puerta está cerrada", True, NEGRO)
        ventana.blit(texto, (ANCHO // 2 - texto.get_width() // 2, 60))
        tiempo_mensaje_puerta_cerrada -= 1
        if tiempo_mensaje_puerta_cerrada <= 0:
            mostrar_mensaje_puerta_cerrada = False

    # Límite de pantalla
    jugador.x = max(0, min(jugador.x, ANCHO - jugador.width))
    jugador.y = max(0, min(jugador.y, ALTO - jugador.height))

    if vidas <= 0:
        estado = PERDISTE


def posicion_valida_botellas(x, y,  ancho =40, alto=60):
    rect_botella = pygame.Rect(x, y, ancho, alto)
    for obs in obstaculos_sala2:
        if rect_botella.colliderect(obs):
            return False
        return True

def sala_2():
    global jugador, vidas, botellas, tiempo_spawn_botella, mostrar_mensaje, tiempo_mensaje, sala_actual, estado

    SALA_ANCHO = 1600  # Sala más larga
    desplazamiento_x = jugador.x - ANCHO // 2
    desplazamiento_x = max(0, min(desplazamiento_x, SALA_ANCHO - ANCHO))

    if fondo_sala2:
        ventana.blit(fondo_sala2, (0, 0))
    else:
        ventana.fill((180, 180, 200))
    mostrar_cronometro()

    dibujar_vidas(ventana, vidas)

    # Spawneo botellas
    tiempo_spawn_botella += 1
    if tiempo_spawn_botella >= spawn_interval:
        tiempo_spawn_botella = 0
        while True:
            x = random.randint(ANCHO, SALA_ANCHO - 50)  # Aparecen fuera de pantalla visible
            y = random.randint(50, ALTO - 110)
            if posicion_valida_botellas(x, y):
                break
        nueva_botella = pygame.Rect(x, y, 40, 60)
        botellas.append(nueva_botella)

    # Mover y dibujar botellas
    for botella in botellas[:]:
        nueva_x = botella.x - velocidad_botella
        rect_nueva_pos = pygame.Rect(nueva_x, botella.y, botella.width, botella.height)
        
        choca = False
        for obs in obstaculos_sala2:
            if rect_nueva_pos.colliderect(obs):
                choca = True
                break

        if not choca:
            botella.x = nueva_x
        else:
            botellas.remove(botella)
            continue

        if imagen_botella:
            ventana.blit(imagen_botella, (botella.x - desplazamiento_x, botella.y))
        else:
            pygame.draw.rect(ventana, (0, 200, 0), (botella.x - desplazamiento_x, botella.y, botella.width, botella.height))

        if botella.right < 0:
            botellas.remove(botella)

        if jugador.colliderect(botella):
            vidas -= 1
            botellas.remove(botella)
            jugador.x -= 20
            jugador.x = min(jugador.x, SALA_ANCHO - jugador.width)

    # Dibujar jugador (ajustado al desplazamiento)
    teclas = pygame.key.get_pressed()
    dibujar_jugador_animado(jugador.x - desplazamiento_x, jugador.y, teclas)



    # Dibujar puerta al final
    puerta_salida = pygame.Rect(SALA_ANCHO - 50, 250, 40, 100)
    

    # Mostrar mensaje inicial
    if mostrar_mensaje:
        texto = fuente_peque.render("Cuidado con las botellas", True, NEGRO)
        ventana.blit(texto, (ANCHO // 2 - texto.get_width() // 2, 20))
        tiempo_mensaje += 1
        if tiempo_mensaje > FPS * 4:
            mostrar_mensaje = False

    # Movimiento jugador
    teclas = pygame.key.get_pressed()
    mover_jugador(teclas, jugador, velocidad, obstaculos_sala2)

    jugador.x = max(0, min(jugador.x, SALA_ANCHO - jugador.width))
    jugador.y = max(0, min(jugador.y, ALTO - jugador.height))

    # Colisión con puerta (pasar a sala 3)
    if jugador.colliderect(puerta_salida):
        sala_actual = 3
        jugador.x, jugador.y = 100, 300
        mostrar_mensaje = True
        tiempo_mensaje = 0
        botellas.clear()

    # Si se queda sin vidas
    if vidas <= 0:
        estado = PERDISTE

def sala_3():
    global jugador, vidas, Conductos, gases_activos
    global tiempo_spawn_gas, mostrar_mensaje, tiempo_mensaje, estado, sala_actual
    global cooldown_gas

    if fondo_sala3:
        ventana.blit(fondo_sala3, (0, 0))
    else:
        ventana.fill((100, 100, 120))
    mostrar_cronometro()
    

    dibujar_vidas(ventana, vidas)

    SALA_ANCHO = 800
    desplazamiento_x = jugador.x - ANCHO // 2
    desplazamiento_x = max(0, min(desplazamiento_x, SALA_ANCHO - ANCHO))

    for obs in obstaculos_sala3:
        obs_dibujado = obs.copy()
        obs_dibujado.x -= desplazamiento_x
        

    # Crear conductos solo una vez
    if not Conductos:
        posiciones_conductos = [
            (80, 70),
            (160, 70),
            (245, 70),
            (550, 70),
            (640, 70),
            (383, 600)  # Este es el conducto central
        ]
        for x, y in posiciones_conductos:
            Conductos.append(pygame.Rect(x, y, 30, 60))
    # Generar todos los gases al mismo tiempo cada 2 segundos
    tiempo_spawn_gas += 1
    if tiempo_spawn_gas >= spawn_interval_gas:
        tiempo_spawn_gas = 0
        gases_activos.clear()
        for c in Conductos:
            is_central = (c.x == 383)
            if is_central:
                largo_gas = ALTO # Longitud fija para el conducto central
            else:
                largo_gas = random.randint(300, 600) # Longitud aleatoria para los demás
            
            # Ahora el gas se crea con altura inicial 0 y dirección 1 (crecer)
            velocidad_gas = 3
            gas_data = {
                "rect": pygame.Rect(c.x + c.width // 2 - 10, c.y + c.height, 20, 0),
                "altura_actual": 0,
                "altura_maxima": largo_gas,
                "direccion": 1,
                "pos_y_base": c.y + c.height,
                "pos_y_conducto": c.y,
                "velocidad": velocidad_gas,
                "central": is_central,
                "frame": 0,
                "frame_timer": 0,
                "frame_interval": 6
            }
            gases_activos.append(gas_data)


    # Actualizar y dibujar gases
    for gas in gases_activos[:]:
        
        # Movimiento del gas: crece o se encoge
        gas["altura_actual"] += gas["velocidad"] * gas["direccion"]
        
        # Cambiar dirección si llega a los límites
        if gas["altura_actual"] >= gas["altura_maxima"]:
            gas["direccion"] = -1
        elif gas["altura_actual"] <= 0:
            gas["direccion"] = 1
        
        # Ajustar el rect del gas
        if gas["pos_y_base"] < ALTO // 2: # Conductos superiores
            gas["rect"].height = gas["altura_actual"]
        else: # Conductos inferiores
            gas["rect"].y = gas["pos_y_conducto"] - gas["altura_actual"]
            gas["rect"].height = gas["altura_actual"]

        # Dibujar gas
        gas_dibujo = gas["rect"].copy()
        gas_dibujo.x -= desplazamiento_x

        if sprites_gas:
            gas["frame_timer"] += 1
            if gas["frame_timer"] >= gas["frame_interval"]:
                gas["frame_timer"] = 0
                gas["frame"] = (gas["frame"] + 1) % len(sprites_gas)
            sprite_actual = sprites_gas[gas["frame"]]
            ampliar_x = 2.5
            ampliar_y = 1.2

            nuevo_ancho = int(gas_dibujo.width * ampliar_x)
            nuevo_alto = int(gas_dibujo.height * ampliar_y)

            sprite_escalado = pygame.transform.scale(sprite_actual, (nuevo_ancho, nuevo_alto))

            ajuste_x = (nuevo_ancho - gas_dibujo.width) // 2
            ajuste_y = (nuevo_alto - gas_dibujo.height)

            ventana.blit(sprite_escalado, (gas_dibujo.x - ajuste_x, gas_dibujo.y - ajuste_y))
        else:
            pygame.draw.rect(ventana, (150, 255, 150), gas_dibujo)
        


    # Colisión con gases (con cooldown)
    cooldown_gas = max(0, cooldown_gas - 1)
    jugador_global = jugador.copy()
    for gas in gases_activos:
        if jugador_global.colliderect(gas["rect"]):
            if cooldown_gas == 0:
                vidas -= 1
                cooldown_gas = FPS // 2
                if vidas <= 0:
                    estado = PERDISTE
            break
    
    

    # Dibujar jugador
    teclas = pygame.key.get_pressed()
    dibujar_jugador_animado(jugador.x - desplazamiento_x, jugador.y, teclas)


    # Puerta de salida
    puerta_salida = pygame.Rect(SALA_ANCHO - 30, 270, 40, 100)
    

    # Mensaje inicial
    if mostrar_mensaje:
        texto = fuente_peque.render("¡Todos los conductos liberan gas cada 2s!", True, NEGRO)
        ventana.blit(texto, (ANCHO // 2 - texto.get_width() // 2, 20))
        tiempo_mensaje += 1
        if tiempo_mensaje > FPS * 4:
            mostrar_mensaje = False

    # Movimiento jugador
    teclas = pygame.key.get_pressed()
    mover_jugador(teclas, jugador, velocidad, obstaculos_sala3)

    

    jugador.x = max(0, min(jugador.x, SALA_ANCHO - jugador.width))
    jugador.y = max(0, min(jugador.y, ALTO - jugador.height))

    # Ir al menú al llegar a la puerta
    if jugador.colliderect(puerta_salida):
        
        sala_actual = 4
        jugador.x, jugador.y = 100, 300
        mostrar_mensaje = True
        tiempo_mensaje = 0
        Conductos.clear()
        gases_activos.clear()
        tiempo_spawn_gas = 0
        cooldown_gas = 0
    
def sala_4():
    global jugador, vidas, estado, sala_actual
    global gas_sala4, gas_velocidad
    global puertas_sala4, puerta_abierta, tiempo_puerta
    global mostrar_mensaje_puerta, tiempo_mensaje_puerta
    global jugador_se_movio_sala4, tiempo_espera_gas_sala4
    global capa_mancha
    SALA_ANCHO = 800
    desplazamiento_x = jugador.x - ANCHO // 2
    desplazamiento_x = max(0, min(desplazamiento_x, SALA_ANCHO - ANCHO))
   
    ventana.blit(capa_mancha, (0, 0))

    if fondo_sala4:
        ventana.blit(fondo_sala4, (0, 0))
    else:
        ventana.fill((80, 60, 90))
    mostrar_cronometro()
    dibujar_vidas(ventana, vidas)

    # Detectar primer movimiento del jugador
    teclas = pygame.key.get_pressed()
    movimiento = teclas[pygame.K_LEFT] or teclas[pygame.K_RIGHT] or teclas[pygame.K_UP] or teclas[pygame.K_DOWN]

    if movimiento and not jugador_se_movio_sala4:
        jugador_se_movio_sala4 = True
        tiempo_espera_gas_sala4 = pygame.time.get_ticks()

    # Aparece gas 1 segundo después del primer movimiento
    if jugador_se_movio_sala4 and gas_sala4 is None:
        if pygame.time.get_ticks() - tiempo_espera_gas_sala4 >= 1000:
            gas_sala4 = pygame.Rect(0, 0, 150, ALTO)

    # Mover gas si existe
    if gas_sala4:
        gas_sala4.x += gas_velocidad
        #gas oscuro
        if imagen_gas_oscuro:
            ancho_sombra = int(900)
            alto_sombra = ALTO
            sombra_gas = pygame.transform.scale(imagen_gas_oscuro, (ancho_sombra, alto_sombra))

            sombra_gas.set_alpha(200)
            ventana.blit(sombra_gas, (gas_sala4.x - desplazamiento_x - ancho_sombra, gas_sala4.y))
        #gas del frente
        if imagen_gas_frente:
            gas_escalado = pygame.transform.scale(imagen_gas_frente, (gas_sala4.width, gas_sala4.height))
            ventana.blit(gas_escalado, (gas_sala4.x - desplazamiento_x -100, gas_sala4.y))
        else:
            pygame.draw.rect(ventana, (180, 255, 180), (gas_sala4.x - desplazamiento_x, gas_sala4.y, gas_sala4.width, gas_sala4.height))
        if jugador.colliderect(gas_sala4):
            vidas -= 1
            if vidas <= 0:
                estado = PERDISTE
      

    # Crear puertas si aún no existen
    if not puertas_sala4:
        puertas_sala4 = [
            pygame.Rect(630, 80, 60, 100),
            # Puerta 2
            pygame.Rect(710, 80, 60, 100),
            # Puerta 3
            pygame.Rect(540, 80, 60, 100),
            # Puerta 4
            pygame.Rect(460, 80, 60, 100)
        ]
    # Controlar puertas (abrir/cerrar cada 5 segundos)
    tiempo_puerta += 1
    if tiempo_puerta >= FPS * 5:
        tiempo_puerta = 0
        anterior = puerta_abierta
        while True:
            nueva = random.choice(puertas_sala4)
            if nueva != anterior:
                puerta_abierta = nueva
                break

        
    # Dibujar jugador
    teclas = pygame.key.get_pressed()
    dibujar_jugador_animado(jugador.x - desplazamiento_x, jugador.y, teclas)


    # Movimiento del jugador
    mover_jugador(teclas, jugador, velocidad, obstaculos_sala4)

    jugador.x = max(0, min(jugador.x, SALA_ANCHO - jugador.width))
    jugador.y = max(0, min(jugador.y, ALTO - jugador.height))

    # Interacción con puertas (tecla espacio)
    if teclas[pygame.K_SPACE]:
        for puerta in puertas_sala4:
            if jugador.colliderect(puerta):
                if puerta != puerta_abierta:
                    mostrar_mensaje_puerta = True
                    tiempo_mensaje_puerta = FPS * 2
                else:
                    sala_actual = 5
                    jugador.x, jugador.y = 100, 300
                    # Reiniciar variables
                    gas_sala4 = None
                    puertas_sala4.clear()
                    puerta_abierta = None
                    tiempo_puerta = 0
                    mostrar_mensaje_puerta = False
                    tiempo_mensaje_puerta = 0
                    jugador_se_movio_sala4 = False
                    tiempo_espera_gas_sala4 = 0
                break

    # Mostrar mensaje si puerta cerrada
    if mostrar_mensaje_puerta:
        mensaje = fuente_peque.render("Esta puerta está cerrada", True, BLANCO)
        ventana.blit(mensaje, (ANCHO // 2 - mensaje.get_width() // 2, 30))
        tiempo_mensaje_puerta -= 1
        if tiempo_mensaje_puerta <= 0:
            mostrar_mensaje_puerta = False

def sala_5():
    
    global jugador, vidas, estado, sala_actual
    global guarda, camino_correcto, tiempo_mensaje, mostrar_mensaje
    global inicio_dialogo_guardia, guardia_hablando
    global puertas_sala5, mensaje_mostrado
    global guarda_fase_movimiento
    global destino_x_guarda
    global direccion_guardia, frame_guardia, contador_guardia, frecuencia_animacion_guardia
    
    
    if fondo_sala5:
        ventana.blit(fondo_sala5, (0, 0))
    else:
        ventana.fill((90, 90, 110))
    mostrar_cronometro()
    dibujar_vidas(ventana, vidas)

    # Fase inicial: primera vez que se entra
    if not hasattr(sala_5, "inicializado"):
        jugador.x, jugador.y = 400, 350
        puertas_sala5 = [
            pygame.Rect(130, 45, 60, 80),
            pygame.Rect(370, 45, 60, 80),
            pygame.Rect(620, 45, 60, 80)
        ]
        camino_correcto = random.choice([0, 1, 2])
        guarda = pygame.Rect(-50, jugador.y, 40, 40)
        guardia_hablando = True
        mensaje_mostrado = False
        inicio_dialogo_guardia = pygame.time.get_ticks()
        guarda_fase_movimiento = "entrada"
        destino_x_guarda = puertas_sala5[camino_correcto].x
        sala_5.inicializado = True
    
    # Dibujar puertas
    
    # Dibujar jugador
    teclas = pygame.key.get_pressed()
    dibujar_jugador_animado(jugador.x, jugador.y, teclas)

    # -- Lógica del guarda --

    # Fase 1: El guarda entra y se detiene frente al jugador para hablar
    if guarda_fase_movimiento == "entrada":
        if guarda.x < jugador.x - 50:
            guarda.x += 2
            
        else:
            if not mensaje_mostrado:
                texto = fuente_peque.render("Ven, la salida es por aquí", True, BLANCO)
                ventana.blit(texto, (guarda.x + 40, guarda.y - 20))
                if pygame.time.get_ticks() - inicio_dialogo_guardia > 5000:
                    mensaje_mostrado = True
                    if camino_correcto == 1:
                        # Si es la puerta central, el camino es más corto
                        guarda_fase_movimiento = "a_puerta_y"
                        destino_x_guarda = puertas_sala5[camino_correcto].x
                    else:
                        # Si es una de las puertas laterales, el camino es más largo
                        guarda_fase_movimiento = "a_punto_giro_x"

    # Fase 2A: Moverse a un punto de giro intermedio (solo para puertas laterales)
    elif guarda_fase_movimiento == "a_punto_giro_x":
        destino_giro_x = ANCHO // 2 
        if guarda.x != destino_giro_x:
            if guarda.x < destino_giro_x:
                guarda.x += 2
                
            else:
                guarda.x -= 2
        else:
            guarda_fase_movimiento = "a_puerta_y"
    
    # Fase 2B/3A: Moverse verticalmente hacia la puerta
    elif guarda_fase_movimiento == "a_puerta_y":
        destino_y = puertas_sala5[camino_correcto].y + puertas_sala5[camino_correcto].height // 2
        if guarda.y > destino_y:
            guarda.y -= 2
            
        else:
            if camino_correcto == 1:
                guarda_fase_movimiento = "detenido"
            else:
                guarda_fase_movimiento = "a_puerta_x"
    
    # Fase 3B: Moverse horizontalmente hacia la puerta final (solo para puertas laterales)
    elif guarda_fase_movimiento == "a_puerta_x":
        destino_x = puertas_sala5[camino_correcto].x
        if guarda.x != destino_x:
            if guarda.x < destino_x:
                guarda.x += 2
                direccion_guardia = "derecha"
            else:
                guarda.x -= 2
                direccion_guardia = "izquierda"
        else:
            guarda_fase_movimiento = "detenido"

    # Fase final: El guarda está detenido, el jugador puede moverse
    elif guarda_fase_movimiento == "detenido":
        pass

    # Dibujar guarda
    if sprites_guardia[direccion_guardia]:
        contador_guardia += 1
        if contador_guardia >= frecuencia_animacion_guardia:
            contador_guardia = 0
            frame_guardia = (frame_guardia + 1) % len(sprites_guardia[direccion_guardia])
        ventana.blit(sprites_guardia[direccion_guardia][frame_guardia], (guarda.x, guarda.y))
    else:
        pygame.draw.rect(ventana, NEGRO, guarda)

    # -- Lógica del jugador --
    if guarda_fase_movimiento == "detenido":
        teclas = pygame.key.get_pressed()
        mover_jugador(teclas, jugador, velocidad, obstaculos_sala5,)

        for i, puerta in enumerate(puertas_sala5):
            if jugador.colliderect(puerta):
                if i == camino_correcto:
                    estado = VICTORIA
                    sala_actual = 1
                    if hasattr(sala_5, "inicializado"):
                        del sala_5.inicializado
                else:
                    estado = PERDISTE
                    sala_actual = 1
                    if hasattr(sala_5, "inicializado"):
                        del sala_5.inicializado
   
            
def mostrar_victoria():
    if imagen_victoria:
        ventana.blit(imagen_victoria, (0, 0))
    else:
        ventana.fill((0, 50, 0))
    
def mostrar_derrota():
    if imagen_derrota:
        ventana.blit(imagen_derrota, (0,0))
    else:
        ventana.fill((0, 50, 0))

estado_anterior = None
# Bucle principal
corriendo = True
while corriendo:
    clock.tick(FPS)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            corriendo = False

        elif evento.type == pygame.MOUSEBUTTONDOWN and estado == MENU:
            if botones["JUGAR"].collidepoint(evento.pos):
                estado = JUEGO
                vidas = 5
                sala_actual = 1
                jugador.x, jugador.y = 100, 300
                mostrar_mensaje = True
                tiempo_mensaje = 0
                botellas.clear()
                estado = JUEGO
                #reincio de sala 4
                gas_sala4 = None
                jugador_se_movio_sala4 = False
                tiempo_espera_gas_sala4 = 0
                puertas_sala4.clear()
                puerta_abierta = None
                tiempo_puerta = 0
                mostrar_mensaje_puerta = False
                tiempo_mensaje_puerta = 0
                tiempo_total = 100
                tiempo_inicio = pygame.time.get_ticks()
            elif botones["REGLAS"].collidepoint(evento.pos):
                estado = REGLAS
            elif botones["SALIR"].collidepoint(evento.pos):
                corriendo = False

        elif evento.type == pygame.MOUSEBUTTONDOWN and estado == PERDISTE:
            if botones_derrota["VOLVER A JUGAR"].collidepoint(evento.pos):
                vidas = 5
                sala_actual = 1
                jugador.x, jugador.y = 100, 300
                mostrar_mensaje = True
                tiempo_mensaje = 0
                botellas.clear()
                estado = JUEGO
                #reincio de sala 4
                gas_sala4 = None
                jugador_se_movio_sala4 = False
                tiempo_espera_gas_sala4 = 0
                puertas_sala4.clear()
                puerta_abierta = None
                tiempo_puerta = 0
                mostrar_mensaje_puerta = False
                tiempo_mensaje_puerta = 0
                tiempo_total = 100
                tiempo_inicio = pygame.time.get_ticks()
            elif botones_derrota["VOLVER AL MENU"].collidepoint(evento.pos):
                vidas = 5
                jugador.x, jugador.y = 100, 300
                mostrar_mensaje = True
                tiempo_mensaje = 0
                botellas.clear()
                estado = JUEGO
                #reincio de sala 4
                gas_sala4 = None
                jugador_se_movio_sala4 = False
                tiempo_espera_gas_sala4 = 0
                puertas_sala4.clear()
                puerta_abierta = None
                tiempo_puerta = 0
                mostrar_mensaje_puerta = False
                tiempo_mensaje_puerta = 0
                tiempo_total = 100
                tiempo_inicio = pygame.time.get_ticks()
                estado = MENU
            elif botones_derrota["SALIR"].collidepoint(evento.pos):
                corriendo = False

        elif evento.type  == pygame.MOUSEBUTTONDOWN and estado == VICTORIA:
            if botones_victoria["JUGAR DE NUEVO"].collidepoint(evento.pos):
                estado = JUEGO
                vidas = 5
                sala_actual = 1
                jugador.x, jugador.y = 100, 300
                mostrar_mensaje = True
                tiempo_mensaje = 0
                botellas.clear()
                estado = JUEGO
                #reincio de sala 4
                gas_sala4 = None
                jugador_se_movio_sala4 = False
                tiempo_espera_gas_sala4 = 0
                puertas_sala4.clear()
                puerta_abierta = None
                tiempo_puerta = 0
                mostrar_mensaje_puerta = False
                tiempo_mensaje_puerta = 0
                tiempo_total = 100
                tiempo_inicio = pygame.time.get_ticks()
            elif botones_victoria["SALIR"].collidepoint(evento.pos):
                corriendo = False

        elif evento.type == pygame.KEYDOWN:
            if estado == REGLAS and evento.key == pygame.K_ESCAPE:
                estado = MENU
            if estado == JUEGO and evento.key == pygame.K_ESCAPE:
                estado = MENU
    if estado != estado_anterior:
        if estado == MENU:
            reproducir_musica(menu_)
        elif estado == JUEGO:
            reproducir_musica(menu_juego)
        elif estado == PERDISTE:
            reproducir_musica(menu_derrota)
        elif estado == VICTORIA:
            reproducir_musica(menu_victoria)
        estado_anterior = estado
    
    if estado == MENU:
        dibujar_menu()
    elif estado == REGLAS:
        mostrar_reglas()
    elif estado == JUEGO:
        if sala_actual == 1:
            sala_1()
        elif sala_actual == 2:
            sala_2()
        elif sala_actual == 3:
            sala_3()
        elif sala_actual == 4:
            sala_4()
        elif sala_actual == 5:
            sala_5()
    elif estado == PERDISTE:
        mostrar_derrota()
    elif estado == VICTORIA:
        mostrar_victoria()


    pygame.display.flip()

pygame.quit()
sys.exit()
